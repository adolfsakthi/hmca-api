<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SuperAdmin\PropertyController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PMS\AmenityController;
use App\Http\Controllers\PMS\HousekeepingController;
use App\Http\Controllers\PMS\POSController;
use App\Http\Controllers\PMS\POSItemController;
use App\Http\Controllers\PMS\RateTypeController;
use App\Http\Controllers\PMS\ReservationController;
use App\Http\Controllers\PMS\RoomController;
use App\Http\Controllers\PMS\RoomTypeController;
use App\Http\Controllers\PMS\TaxController;
use App\Http\Controllers\PMS\UserController;
use App\Http\Controllers\SuperAdmin\ModuleController;
use App\Http\Controllers\SuperAdmin\PropertyModuleController;



Route::post('/login', [AuthController::class, 'login']);

Route::middleware(['jwt.custom'])->group(function () {
    Route::post('/refresh-token', [AuthController::class, 'refreshToken']);
    Route::middleware('role:super_admin')->group(function () {
        Route::apiResource('property', PropertyController::class);
        Route::put('property/temporaryDisable/{id}', [PropertyController::class, 'temporaryDisable']);
        Route::apiResource('modules', ModuleController::class);
        Route::get('properties/{id}/modules', [PropertyModuleController::class, 'index']);
        Route::post('properties/{id}/modules', [PropertyModuleController::class, 'assign']);
        Route::delete('properties/{id}/modules', [PropertyModuleController::class, 'remove']);
        Route::patch('properties/{id}/modules/toggle', [PropertyModuleController::class, 'toggle']);
    });
});


Route::prefix('pms')->middleware(['jwt.custom', 'role:property_admin', 'property.inject', 'module.access:pms'])->group(function () {
    Route::post('reservations/{id}', [ReservationController::class, 'update']);
    Route::apiResource('rate-types', RateTypeController::class);
    Route::apiResource('users', UserController::class);
    Route::apiResource('rooms', RoomController::class);
    Route::apiResource('amenities', AmenityController::class);
    Route::apiResource('room-type', RoomTypeController::class);
    Route::apiResource('reservations', ReservationController::class);
    Route::apiResource('pos', POSController::class);
    Route::apiResource('housekeeping', HousekeepingController::class);
    Route::apiResource('tax', TaxController::class);
    Route::apiResource('pos/items', POSItemController::class);
});


Route::prefix('pms')->middleware(['jwt.custom', 'role:front_desk', 'property.inject', 'module.access:pms'])->group(function () {
    Route::apiResource('reservations', ReservationController::class);
});
